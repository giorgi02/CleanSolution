﻿using Core.Application.Interfaces.Services;
using $safeprojectname$.Consumers;
using $safeprojectname$.Producers;
using $safeprojectname$.RequestServices;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$;
public static class ServiceExtensions
{
    public static void AddMessagingLayer(this IServiceCollection services)
    {
        services.AddHostedService<UpsertPositionConsumer>();

        services.AddSingleton<IMessagingService, MessagingServices>();

        services.AddScoped<ICheckPersonsService, CheckPersonsService>();
    }
}