﻿namespace $safeprojectname$.DTOs;
public class GetPositionDto
{
    public Guid Id { get; set; }
    public string? Name { get; set; }
    public double Salary { get; set; }
}