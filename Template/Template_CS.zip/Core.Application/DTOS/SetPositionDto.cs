﻿namespace $safeprojectname$.DTOs;
public class SetPositionDto
{
    public string? Name { get; set; }
    public double Salary { get; set; }
}