﻿using $safeprojectname$.DTOs;
using $safeprojectname$.Interfaces.Repositories;

namespace $safeprojectname$.Interactors.Positions.Queries;
public abstract class GetPositionQuery
{
    public record struct Request : IRequest<IEnumerable<GetPositionDto>>;


    public sealed class Handler : IRequestHandler<Request, IEnumerable<GetPositionDto>>
    {
        private readonly IPositionRepository _repository;
        private readonly IMapper _mapper;

        public Handler(IPositionRepository repository, IMapper mapper)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task<IEnumerable<GetPositionDto>> Handle(Request request, CancellationToken cancellationToken)
        {
            var positions = await _repository.ReadAsync();

            return _mapper.Map<IEnumerable<GetPositionDto>>(positions);
        }
    }
}