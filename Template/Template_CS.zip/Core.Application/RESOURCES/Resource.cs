﻿namespace $safeprojectname$.Localize;
public sealed class Resource { }
