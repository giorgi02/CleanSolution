﻿using Core.Domain.Entities;

namespace $safeprojectname$.Interfaces.Repositories;
public interface IPositionRepository : IRepository<Guid, Position> { }