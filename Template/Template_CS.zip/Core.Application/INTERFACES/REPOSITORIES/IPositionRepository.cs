﻿using Core.Domain.Models;

namespace $safeprojectname$.Interfaces.Repositories;
public interface IPositionRepository : IRepository<Guid, Position> { }