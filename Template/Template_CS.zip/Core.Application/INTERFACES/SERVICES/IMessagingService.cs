﻿using Core.Domain.Models;

namespace $safeprojectname$.Interfaces.Services;
public interface IMessagingService
{
    Task EmployeeCreated(Employee employee);
}
