﻿using Core.Domain.Models;

namespace $safeprojectname$.Interfaces.Services;
public interface ICheckPersonsService
{
    Task<Employee> GetPerson(string personalNumber, CancellationToken cancellationToken);
}
