﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace $safeprojectname$.Extensions.Attributes;
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class SkipActionLoggingAttribute : ActionFilterAttribute
{
}
