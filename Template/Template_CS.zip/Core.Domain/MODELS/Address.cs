﻿namespace $safeprojectname$.Models;
public record class Address(string City, string Street);