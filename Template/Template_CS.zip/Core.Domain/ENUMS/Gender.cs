﻿namespace $safeprojectname$.Enums;
public enum Gender : byte
{
    Female = 0,
    Male = 1
}