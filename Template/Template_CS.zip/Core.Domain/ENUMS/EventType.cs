﻿namespace $safeprojectname$.Enums;
public enum EventType : byte
{
    Create = 0,
    Update = 1,
    Delete = 2,
}
