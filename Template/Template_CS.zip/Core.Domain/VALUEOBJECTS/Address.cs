﻿namespace $safeprojectname$.Entities
{
    public record class Address(string City, string Street);
}