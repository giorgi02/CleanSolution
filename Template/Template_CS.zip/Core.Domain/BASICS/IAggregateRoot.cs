﻿namespace $safeprojectname$.Basics
{
    public interface IAggregateRoot { }
}
