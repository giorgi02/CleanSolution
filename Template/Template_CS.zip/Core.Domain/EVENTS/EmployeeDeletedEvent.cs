﻿//using $safeprojectname$.Basics;
//using $safeprojectname$.Models;

//namespace $safeprojectname$.Events;
//internal record class EmployeeDeletedEvent : Event<Employee>
//{
//}
