﻿//namespace $safeprojectname$.Events;

//internal record class UpdateEmployeeEvent : Event
//{
//}
