﻿//namespace $safeprojectname$.Events;

//internal record class DeleteEmployeeEvent : Event
//{
//}
