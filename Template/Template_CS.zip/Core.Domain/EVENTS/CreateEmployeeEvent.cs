﻿//namespace $safeprojectname$.Events;

//internal record class CreateEmployeeEvent : Event
//{
//}
